const mongoose = require('mongoose');

mongoose.connect(process.env.MONGO_URI, {
  serverSelectionTimeoutMS: 30000
}).then(() => console.log('Mongo Connected')).catch(console.error);

const Verified = mongoose.model('Verified', new mongoose.Schema({
  discordId: String,
  robloxId: String,
  username: String
}));

const Codes = mongoose.model('Codes', new mongoose.Schema({
  discordId: String,
  robloxId: String,
  code: String,
  createdAt: { type: Date, default: Date.now, expires: 600 } // expire in 10 min
}));

const Rankbinds = mongoose.model('Rankbinds', new mongoose.Schema({
  groupId: String,
  roleNames: [String],
  discordRoles: [String],
  nickname: String
}));

const Blacklist = mongoose.model('Blacklist', new mongoose.Schema({
  groupId: String
}));

module.exports = { Verified, Codes, Rankbinds, Blacklist };